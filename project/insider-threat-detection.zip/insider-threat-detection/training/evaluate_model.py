"""Evaluate the SAVED models on the held-out test set and write reports + plots.

Run from the project root:   python training/evaluate_model.py
(Requires `python training/train_model.py` to have been run first.)
"""
import json
import sys
from pathlib import Path

import joblib
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from sklearn.inspection import permutation_importance
from sklearn.metrics import (ConfusionMatrixDisplay, accuracy_score, classification_report, confusion_matrix,
                             f1_score, precision_score, recall_score, roc_auc_score, roc_curve)

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from training.common import FEATURES, MODELS_DIR, RANDOM_STATE, REPORTS_DIR  # noqa: E402
from training.train_model import get_split  # noqa: E402


def metrics_for(y_true, y_pred, y_prob):
    return {"accuracy": accuracy_score(y_true, y_pred), "precision": precision_score(y_true, y_pred),
            "recall": recall_score(y_true, y_pred), "f1": f1_score(y_true, y_pred),
            "roc_auc": roc_auc_score(y_true, y_prob)}


def main():
    REPORTS_DIR.mkdir(exist_ok=True)
    _, X_test, _, y_test = get_split()
    X_test = X_test[FEATURES]
    en = joblib.load(MODELS_DIR / "elastic_net_pipeline.joblib")
    rf = joblib.load(MODELS_DIR / "random_forest_pipeline.joblib")
    iso = joblib.load(MODELS_DIR / "isolation_forest.joblib")

    results, probs = {}, {}
    for name, model in [("Elastic Net Logistic Regression", en), ("Random Forest", rf)]:
        prob = model.predict_proba(X_test)[:, 1]
        pred = (prob >= 0.5).astype(int)  # fixed 0.5 threshold, NOT tuned on the test set
        results[name] = {k: float(v) for k, v in metrics_for(y_test, pred, prob).items()}
        results[name]["confusion_matrix"] = confusion_matrix(y_test, pred).tolist()
        probs[name] = prob
        if name.startswith("Elastic"):
            en_pred = pred
            report = classification_report(y_test, pred, target_names=["Normal", "Insider Threat"], digits=4)
    (REPORTS_DIR / "classification_report.txt").write_text(
        "Elastic Net Logistic Regression - held-out test set (n=%d)\n\n%s" % (len(y_test), report))

    # ---- Isolation Forest: labels used ONLY here, for comparison ----------------------------
    iso_flag = (iso.predict(X_test) == -1).astype(int)       # -1 = anomaly
    iso_score = -iso.decision_function(X_test)               # higher = more anomalous
    iso_res = {"flagged_anomalies": int(iso_flag.sum()),
               "precision": float(precision_score(y_test, iso_flag, zero_division=0)),
               "recall": float(recall_score(y_test, iso_flag)),
               "f1": float(f1_score(y_test, iso_flag, zero_division=0)),
               "roc_auc_of_anomaly_score": float(roc_auc_score(y_test, iso_score)),
               "confusion_matrix": confusion_matrix(y_test, iso_flag).tolist()}
    results["Isolation Forest (unsupervised, label-free)"] = {
        "accuracy": float(accuracy_score(y_test, iso_flag)), "precision": iso_res["precision"],
        "recall": iso_res["recall"], "f1": iso_res["f1"], "roc_auc": iso_res["roc_auc_of_anomaly_score"],
        "confusion_matrix": iso_res["confusion_matrix"]}

    # ---- tables ------------------------------------------------------------------------------
    comp = pd.DataFrame({k: {m: v[m] for m in ["accuracy", "precision", "recall", "f1", "roc_auc"]}
                         for k, v in results.items()}).T.round(4)
    comp.index.name = "model"
    comp.to_csv(REPORTS_DIR / "model_comparison.csv")
    meta = json.loads((MODELS_DIR / "model_metadata.json").read_text())
    out = {"test_set_size": int(len(y_test)), "test_threat_count": int(y_test.sum()), "models": results,
           "isolation_forest_detail": iso_res,
           "cross_validation_on_train": {"elastic_net_f1": meta["elastic_net_cv_f1"],
                                         "random_forest_f1": meta["random_forest_cv_f1"]},
           "best_params": {"elastic_net": meta["elastic_net_best_params"],
                           "random_forest": meta["random_forest_best_params"]},
           "caveat": meta["data_note"]}
    (REPORTS_DIR / "metrics.json").write_text(json.dumps(out, indent=2))

    # ---- plots -------------------------------------------------------------------------------
    fig, ax = plt.subplots(figsize=(5, 4.5))
    ConfusionMatrixDisplay(confusion_matrix(y_test, en_pred), display_labels=["Normal", "Threat"]).plot(
        ax=ax, cmap="Blues", colorbar=False)
    ax.set_title("Elastic Net - confusion matrix (test set)")
    fig.tight_layout(); fig.savefig(REPORTS_DIR / "confusion_matrix.png", dpi=150); plt.close(fig)

    fig, ax = plt.subplots(figsize=(5.5, 4.5))
    for name, prob in probs.items():
        fpr, tpr, _ = roc_curve(y_test, prob)
        ax.plot(fpr, tpr, label=f"{name} (AUC={roc_auc_score(y_test, prob):.3f})")
    ax.plot([0, 1], [0, 1], "k--", alpha=.4, label="Chance")
    ax.set(xlabel="False positive rate", ylabel="True positive rate", title="ROC curve (test set)")
    ax.legend(loc="lower right"); fig.tight_layout(); fig.savefig(REPORTS_DIR / "roc_curve.png", dpi=150); plt.close(fig)

    # feature importance: EN coefficients (per encoded feature) + RF permutation importance (per original column)
    names = en.named_steps["preprocess"].get_feature_names_out()
    coefs = pd.Series(en.named_steps["model"].coef_[0], index=names)
    coefs.index = [n.split("__", 1)[1] for n in coefs.index]
    top = coefs.reindex(coefs.abs().sort_values(ascending=False).index).head(12)[::-1]
    # RF importance: impurity-based importance summed back to the ORIGINAL columns (one-hot pieces are
    # added together), plus permutation importance (log-loss) on the test set saved to CSV for reference.
    rf_names = [n.split("__", 1)[1] for n in rf.named_steps["preprocess"].get_feature_names_out()]
    mdi = pd.Series(rf.named_steps["model"].feature_importances_, index=rf_names)
    def original_col(n):
        return next((c for c in FEATURES if n == c or n.startswith(c + "_")), n)
    mdi_orig = mdi.groupby(original_col).sum().reindex(FEATURES)
    rf_imp = mdi_orig.sort_values().tail(12)
    perm = permutation_importance(rf, X_test, y_test, n_repeats=10, random_state=RANDOM_STATE, scoring="neg_log_loss")
    pd.DataFrame({"impurity_importance": mdi_orig, "permutation_importance_logloss": pd.Series(perm.importances_mean, index=FEATURES)}
                 ).sort_values("impurity_importance", ascending=False).to_csv(REPORTS_DIR / "random_forest_importance.csv")
    fig, axes = plt.subplots(1, 2, figsize=(12, 5))
    axes[0].barh(top.index, top.values, color=["#c0392b" if v > 0 else "#2471a3" for v in top.values])
    axes[0].set_title("Elastic Net coefficients (standardised features)\nred = raises threat risk")
    axes[1].barh(rf_imp.index, rf_imp.values, color="#2e8b57")
    axes[1].set_title("Random Forest feature importance\n(impurity-based, summed per original column)")
    fig.tight_layout(); fig.savefig(REPORTS_DIR / "feature_importance.png", dpi=150); plt.close(fig)
    coefs.to_frame("coefficient").assign(zeroed_by_l1=lambda d: d.coefficient == 0).to_csv(
        REPORTS_DIR / "elastic_net_coefficients.csv")

    print(comp.to_string())
    print("\nIsolation Forest detail:", json.dumps(iso_res))
    print(f"Elastic Net: {int((coefs == 0).sum())} of {len(coefs)} coefficients set exactly to 0 by L1")
    print("\n" + report)


if __name__ == "__main__":
    main()
