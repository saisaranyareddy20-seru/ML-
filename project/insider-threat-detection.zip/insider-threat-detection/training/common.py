"""Shared constants and helpers used by training, evaluation, API and monitoring."""
from pathlib import Path
import pandas as pd

ROOT = Path(__file__).resolve().parent.parent
DATA_PATH = ROOT / "data" / "insider_threat_dataset_1500_rows.csv"
MODELS_DIR = ROOT / "models"
REPORTS_DIR = ROOT / "reports"

TARGET = "insider_threat"
RANDOM_STATE = 42
TEST_SIZE = 0.2

# Identifiers and raw dates are NOT predictive features (they would let the model memorise).
ID_COLUMNS = ["event_id", "user_id", "event_date"]
# Suspected leakage: strongly tied to the label, construction unknown (see reports/leakage_check.csv).
LEAKAGE_SUSPECT = "unusual_activity_score"

CATEGORICAL = ["department", "role", "device_type", "operating_system"]
NUMERICAL = [
    "login_count", "login_hour", "failed_logins", "file_access_count",
    "sensitive_files_accessed", "after_hours_access", "external_device_usage",
    "data_download_mb", "access_frequency", "unique_files_accessed",
    "unusual_location", "unusual_login", "email_activity", "http_activity",
]
FEATURES = NUMERICAL + CATEGORICAL

# Validation ranges used by the API (generous, based on the training data + physical limits).
RANGES = {
    "login_count": (0, 200), "login_hour": (0, 23), "failed_logins": (0, 200),
    "file_access_count": (0, 5000), "sensitive_files_accessed": (0, 5000),
    "after_hours_access": (0, 1), "external_device_usage": (0, 1),
    "data_download_mb": (0, 100000), "access_frequency": (0, 1000),
    "unique_files_accessed": (0, 5000), "unusual_location": (0, 1),
    "unusual_login": (0, 1), "email_activity": (0, 2000), "http_activity": (0, 5000),
}
CHOICES = {
    "department": ["Engineering", "Finance", "HR", "IT", "Legal", "Operations", "Sales"],
    "role": ["Administrator", "Analyst", "Contractor", "Employee", "Manager"],
    "device_type": ["Desktop", "Laptop", "Virtual Machine", "Workstation"],
    "operating_system": ["Linux", "Windows", "macOS"],
}

def load_data() -> pd.DataFrame:
    return pd.read_csv(DATA_PATH)
