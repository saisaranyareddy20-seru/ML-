"""Train Elastic Net Logistic Regression (main), Random Forest (comparison) and
Isolation Forest (optional anomaly detector).

Run from the project root:   python training/train_model.py

Lifecycle: load data -> drop identifiers/leakage -> stratified split -> preprocessing
Pipeline (fit on TRAIN only) -> GridSearchCV (CV on TRAIN only) -> save models.
The test set is never used here for tuning or model selection.
"""
import json
import sys
import warnings
from pathlib import Path

import joblib
import numpy as np
import pandas as pd
from sklearn.compose import ColumnTransformer
from sklearn.ensemble import IsolationForest, RandomForestClassifier
from sklearn.impute import SimpleImputer
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import GridSearchCV, StratifiedKFold, cross_val_score, train_test_split
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from training.common import (CATEGORICAL, FEATURES, LEAKAGE_SUSPECT, MODELS_DIR, NUMERICAL,  # noqa: E402
                             RANDOM_STATE, REPORTS_DIR, TARGET, TEST_SIZE, load_data)

# penalty='elasticnet' is required by the course brief; newer scikit-learn only warns about it.
warnings.filterwarnings("ignore", message=".*'penalty' was deprecated.*")

CV = StratifiedKFold(n_splits=5, shuffle=True, random_state=RANDOM_STATE)


# Several metrics are recorded; the winner is picked by CV log-loss, which breaks ties between
# configurations that all reach F1 = 1.0 and favours well-calibrated probabilities.
SCORING = {"f1": "f1", "recall": "recall", "roc_auc": "roc_auc", "neg_log_loss": "neg_log_loss"}
REFIT = "neg_log_loss"


def make_preprocessor(numerical, categorical):
    """Numeric: median impute + standard scale. Categorical: most-frequent impute + one-hot."""
    num = Pipeline([("imputer", SimpleImputer(strategy="median")), ("scaler", StandardScaler())])
    cat = Pipeline([("imputer", SimpleImputer(strategy="most_frequent")),
                    ("onehot", OneHotEncoder(handle_unknown="ignore"))])
    return ColumnTransformer([("num", num, numerical), ("cat", cat, categorical)])


def elastic_net_pipeline(numerical=NUMERICAL, categorical=CATEGORICAL):
    clf = LogisticRegression(penalty="elasticnet", solver="saga", max_iter=5000,
                             class_weight="balanced", random_state=RANDOM_STATE)
    return Pipeline([("preprocess", make_preprocessor(numerical, categorical)), ("model", clf)])


def random_forest_pipeline():
    clf = RandomForestClassifier(class_weight="balanced", random_state=RANDOM_STATE, n_jobs=-1)
    return Pipeline([("preprocess", make_preprocessor(NUMERICAL, CATEGORICAL)), ("model", clf)])


def get_split(df=None):
    """Same stratified split everywhere (training, evaluation, tests) thanks to the fixed seed."""
    df = load_data() if df is None else df
    X, y = df.drop(columns=[TARGET]), df[TARGET]
    return train_test_split(X, y, test_size=TEST_SIZE, stratify=y, random_state=RANDOM_STATE)


def cv_f1(search):
    return float(search.cv_results_["mean_test_f1"][search.best_index_])


def main():
    MODELS_DIR.mkdir(exist_ok=True)
    REPORTS_DIR.mkdir(exist_ok=True)
    df = load_data()

    # ---- data quality checks ---------------------------------------------------------
    quality = {
        "rows": int(len(df)), "columns": int(df.shape[1]),
        "missing_values": int(df.isna().sum().sum()),
        "duplicate_rows": int(df.duplicated().sum()),
        "class_counts": {str(k): int(v) for k, v in df[TARGET].value_counts().items()},
        "threat_rate": float(df[TARGET].mean()),
        "negative_numeric_values": int((df[NUMERICAL] < 0).sum().sum()),
    }
    print("Data quality:", quality)

    X_train, X_test, y_train, y_test = get_split(df)
    print(f"Train {X_train.shape}, Test {X_test.shape}; train threat rate {y_train.mean():.3f}")

    # ---- leakage check (training data only, cross-validation) ---------------------------
    corr = df[NUMERICAL + [LEAKAGE_SUSPECT, TARGET]].corr()[TARGET].drop(TARGET)
    base = elastic_net_pipeline()
    with_score = elastic_net_pipeline(NUMERICAL + [LEAKAGE_SUSPECT], CATEGORICAL)
    cols_without, cols_with = FEATURES, FEATURES + [LEAKAGE_SUSPECT]
    leak = {}
    for name, pipe, cols in [("without_unusual_activity_score", base, cols_without),
                             ("with_unusual_activity_score", with_score, cols_with)]:
        pipe.set_params(model__C=1.0, model__l1_ratio=0.5)
        leak[name] = {m: float(cross_val_score(pipe, X_train[cols], y_train, cv=CV, scoring=m).mean())
                      for m in ["roc_auc", "recall", "f1"]}
    # how well do the other features predict the score itself? (is it derived from them?)
    from sklearn.linear_model import LinearRegression
    from sklearn.model_selection import KFold
    r2_from_features = float(cross_val_score(LinearRegression(), X_train[NUMERICAL], X_train[LEAKAGE_SUSPECT],
                                             cv=KFold(5, shuffle=True, random_state=RANDOM_STATE), scoring="r2").mean())
    leak["r2_of_score_predicted_from_other_numeric_features"] = r2_from_features
    leak["correlation_of_score_with_label"] = float(df[LEAKAGE_SUSPECT].corr(df[TARGET]))
    print("Leakage check (CV on train):", json.dumps(leak, indent=2))
    pd.DataFrame({k: v for k, v in leak.items() if isinstance(v, dict)}).T.to_csv(REPORTS_DIR / "leakage_check.csv")

    # ---- Elastic Net (MAIN MODEL) --------------------------------------------------------
    # Features used: behavioural features only, WITHOUT unusual_activity_score (provenance unknown).
    en_grid = {"model__C": [0.01, 0.1, 1, 10], "model__l1_ratio": [0.1, 0.3, 0.5, 0.7, 0.9]}
    en_search = GridSearchCV(elastic_net_pipeline(), en_grid, cv=CV, scoring=SCORING, refit=REFIT, n_jobs=-1)
    en_search.fit(X_train[FEATURES], y_train)
    print("Elastic Net best:", en_search.best_params_, f"CV F1={cv_f1(en_search):.4f}")
    en_best = en_search.best_estimator_

    # ---- Random Forest (comparison) ------------------------------------------------------
    rf_grid = {"model__n_estimators": [100, 300], "model__max_depth": [None, 6, 12],
               "model__min_samples_leaf": [1, 3]}
    rf_search = GridSearchCV(random_forest_pipeline(), rf_grid, cv=CV, scoring=SCORING, refit=REFIT, n_jobs=-1)
    rf_search.fit(X_train[FEATURES], y_train)
    print("Random Forest best:", rf_search.best_params_, f"CV F1={cv_f1(rf_search):.4f}")
    rf_best = rf_search.best_estimator_

    # ---- Isolation Forest (unsupervised: labels NOT used for fitting) ----------------------
    iso_pre = make_preprocessor(NUMERICAL, CATEGORICAL)
    iso = Pipeline([("preprocess", iso_pre),
                    ("model", IsolationForest(n_estimators=200, contamination=0.1, random_state=RANDOM_STATE))])
    iso.fit(X_train[FEATURES])  # no y passed

    # ---- save ------------------------------------------------------------------------------
    joblib.dump(en_best, MODELS_DIR / "elastic_net_pipeline.joblib")
    joblib.dump(rf_best, MODELS_DIR / "random_forest_pipeline.joblib")
    joblib.dump(iso, MODELS_DIR / "isolation_forest.joblib")

    # training reference for drift monitoring (training split only)
    reference = {"numerical": {c: {"mean": float(X_train[c].mean()), "std": float(X_train[c].std()),
                                   "min": float(X_train[c].min()), "max": float(X_train[c].max()),
                                   "values_sample": X_train[c].sample(min(500, len(X_train)), random_state=RANDOM_STATE).tolist()}
                               for c in NUMERICAL},
                 "categorical": {c: X_train[c].value_counts(normalize=True).to_dict() for c in CATEGORICAL}}
    (MODELS_DIR / "training_reference.json").write_text(json.dumps(reference))

    import sklearn
    metadata = {
        "project": "Insider Threat Detection Using Elastic Net Regularized Logistic Regression",
        "main_model": "elastic_net_pipeline.joblib", "comparison_model": "random_forest_pipeline.joblib",
        "anomaly_model": "isolation_forest.joblib",
        "features": FEATURES, "numerical_features": NUMERICAL, "categorical_features": CATEGORICAL,
        "excluded_identifiers": ["event_id", "user_id", "event_date"],
        "excluded_suspected_leakage": [LEAKAGE_SUSPECT],
        "random_state": RANDOM_STATE, "test_size": TEST_SIZE, "decision_threshold": 0.5,
        "elastic_net_best_params": en_search.best_params_, "elastic_net_cv_f1": cv_f1(en_search),
        "random_forest_best_params": rf_search.best_params_, "random_forest_cv_f1": cv_f1(rf_search),
        "grid_scoring": "5-fold stratified CV on training data only; best model chosen by neg_log_loss (F1/recall/ROC-AUC also recorded)",
        "isolation_forest": {"contamination_assumed": 0.1, "trained_without_labels": True},
        "data_quality": quality, "leakage_check": leak,
        "sklearn_version": sklearn.__version__,
        "data_note": "Dataset provenance is unknown (appears synthetic). Results do not validate real-world performance.",
    }
    (MODELS_DIR / "model_metadata.json").write_text(json.dumps(metadata, indent=2))
    print("Saved models and metadata to", MODELS_DIR)


if __name__ == "__main__":
    main()
