"""Framework-free prediction logic. Used by the FastAPI service AND by tests/Streamlit direct mode.

The saved pipeline contains the same preprocessing used during training, so a request goes:
dict -> DataFrame (column order fixed) -> imputer/scaler/one-hot -> Elastic Net -> probability -> label.
"""
import json
import sys
from functools import lru_cache
from pathlib import Path

import joblib
import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from training.common import FEATURES, MODELS_DIR  # noqa: E402

THRESHOLD = 0.5
DISCLAIMER = ("This is a statistical model prediction based on behavioural features, not proof of malicious intent. "
              "Any flagged activity needs review by a human security analyst.")


@lru_cache(maxsize=1)
def load_models():
    """Load saved pipelines once (cached) - never retrain per request."""
    main = joblib.load(MODELS_DIR / "elastic_net_pipeline.joblib")
    iso_path = MODELS_DIR / "isolation_forest.joblib"
    iso = joblib.load(iso_path) if iso_path.exists() else None
    return main, iso


def model_loaded() -> bool:
    try:
        load_models()
        return True
    except Exception:
        return False


def load_metadata() -> dict:
    return json.loads((MODELS_DIR / "model_metadata.json").read_text())


def predict_record(record: dict) -> dict:
    model, iso = load_models()
    X = pd.DataFrame([{c: record[c] for c in FEATURES}], columns=FEATURES)
    prob = float(model.predict_proba(X)[0, 1])
    pred = int(prob >= THRESHOLD)
    out = {"prediction": pred,
           "result": "Potential Insider Threat" if pred else "Normal Activity",
           "threat_probability": round(prob, 4), "explanation": DISCLAIMER}
    if iso is not None:  # supplementary, label-free anomaly signal
        out["anomaly_flag"] = bool(iso.predict(X)[0] == -1)
    return out
