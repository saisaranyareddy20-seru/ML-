"""FastAPI service.  Run from the project root:  uvicorn app.main:app --reload
Docs (Swagger UI): http://127.0.0.1:8000/docs
"""
import sys
from contextlib import asynccontextmanager
from pathlib import Path
from typing import Literal

from fastapi import FastAPI, Request
from fastapi.exceptions import RequestValidationError
from fastapi.responses import JSONResponse
from pydantic import BaseModel, ConfigDict, Field

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from app import predictor  # noqa: E402
from monitoring.monitor import log_prediction, monitoring_summary  # noqa: E402
from training.common import CHOICES, RANGES  # noqa: E402


def _int(name): lo, hi = RANGES[name]; return Field(..., ge=lo, le=hi, description=f"Integer {lo}-{hi}")


class ActivityRecord(BaseModel):
    """One user-activity record. Identifiers (event_id, user_id) are neither needed nor accepted."""
    model_config = ConfigDict(extra="forbid")  # reject unexpected fields
    login_count: int = _int("login_count")
    login_hour: int = _int("login_hour")
    failed_logins: int = _int("failed_logins")
    file_access_count: int = _int("file_access_count")
    sensitive_files_accessed: int = _int("sensitive_files_accessed")
    after_hours_access: int = _int("after_hours_access")
    external_device_usage: int = _int("external_device_usage")
    data_download_mb: float = Field(..., ge=0, le=RANGES["data_download_mb"][1])
    access_frequency: int = _int("access_frequency")
    unique_files_accessed: int = _int("unique_files_accessed")
    unusual_location: int = _int("unusual_location")
    unusual_login: int = _int("unusual_login")
    email_activity: int = _int("email_activity")
    http_activity: int = _int("http_activity")
    department: Literal["Engineering", "Finance", "HR", "IT", "Legal", "Operations", "Sales"]
    role: Literal["Administrator", "Analyst", "Contractor", "Employee", "Manager"]
    device_type: Literal["Desktop", "Laptop", "Virtual Machine", "Workstation"]
    operating_system: Literal["Linux", "Windows", "macOS"]


class PredictionResponse(BaseModel):
    prediction: int
    result: str
    threat_probability: float
    explanation: str
    anomaly_flag: bool | None = None


@asynccontextmanager
async def lifespan(app: FastAPI):
    try:
        predictor.load_models()  # load once at startup
    except Exception as exc:  # keep service up so /health can report the problem
        print("Model loading failed:", type(exc).__name__)
    yield


app = FastAPI(title="Insider Threat Detection API",
              description="Elastic Net Regularized Logistic Regression insider-threat classifier.",
              version="1.0.0", lifespan=lifespan)


@app.exception_handler(RequestValidationError)
async def validation_handler(request: Request, exc: RequestValidationError):
    errors = [{"field": ".".join(str(p) for p in e["loc"][1:]) or "body", "problem": e["msg"]} for e in exc.errors()]
    return JSONResponse(status_code=422, content={"detail": "Invalid input", "errors": errors})


@app.get("/")
def root():
    return {"service": "Insider Threat Detection API", "model": "Elastic Net Logistic Regression",
            "endpoints": ["/health", "/predict", "/monitoring", "/docs"]}


@app.get("/health")
def health():
    ok = predictor.model_loaded()
    return {"status": "ok" if ok else "model_not_loaded", "model_loaded": ok}


@app.post("/predict", response_model=PredictionResponse)
def predict(record: ActivityRecord):
    if not predictor.model_loaded():
        return JSONResponse(status_code=503, content={"detail": "Model not available. Train it first."})
    data = record.model_dump()
    try:
        result = predictor.predict_record(data)
    except Exception:  # do not leak internals
        return JSONResponse(status_code=500, content={"detail": "Prediction failed."})
    log_prediction(data, result["prediction"], result["threat_probability"])
    return result


@app.get("/monitoring")
def monitoring():
    return monitoring_summary()
