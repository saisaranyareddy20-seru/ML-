"""Streamlit dashboard.   Run from the project root:   streamlit run app/streamlit_app.py

Talks to the FastAPI service (API_URL env var, default http://127.0.0.1:8000).
"Local model" mode loads the saved pipeline directly - handy if the API isn't deployed.
"""
import json
import os
import sys
from pathlib import Path

import pandas as pd
import requests
import streamlit as st

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
from training.common import CATEGORICAL, CHOICES, FEATURES, NUMERICAL, RANGES, load_data  # noqa: E402
from training.train_model import get_split  # noqa: E402

API_URL = os.environ.get("API_URL", "http://127.0.0.1:8000")
REPORTS = ROOT / "reports"

st.set_page_config(page_title="Insider Threat Detection", page_icon="🛡️", layout="wide")
st.title("🛡️ Insider Threat Detection")
st.caption("Elastic Net Regularized Logistic Regression · Machine Learning (25SC2107E)")
st.write("Enter a user's behavioural activity and the model estimates the probability that it is a "
         "potential insider threat. Trained on a 1,500-row dataset of unknown (likely synthetic) origin.")

mode = st.sidebar.radio("Prediction source", ["FastAPI service", "Local model"])
st.sidebar.write(f"API URL: `{API_URL}`")


@st.cache_data
def example_rows():
    """One normal and one threat record taken from the real held-out test split."""
    _, X_test, _, y_test = get_split()
    return {"Normal example (from test set)": X_test[y_test == 0].iloc[0][FEATURES].to_dict(),
            "Threat example (from test set)": X_test[y_test == 1].iloc[0][FEATURES].to_dict(),
            "Blank form": None}


examples = example_rows()
choice = st.selectbox("Pre-fill the form with a real dataset record", list(examples))
base = examples[choice] or {c: (0 if c in NUMERICAL else CHOICES[c][0]) for c in FEATURES}

tab_pred, tab_metrics, tab_monitor = st.tabs(["Predict", "Model evaluation", "Monitoring"])

with tab_pred:
    with st.form("form"):
        cols = st.columns(3)
        values = {}
        for i, f in enumerate(NUMERICAL):
            lo, hi = RANGES[f]
            with cols[i % 3]:
                if f == "data_download_mb":
                    values[f] = st.number_input(f, 0.0, float(hi), float(base[f]))
                else:
                    values[f] = st.number_input(f, lo, hi, int(base[f]), step=1)
        for i, f in enumerate(CATEGORICAL):
            with cols[i % 3]:
                values[f] = st.selectbox(f, CHOICES[f], index=CHOICES[f].index(base[f]))
        go = st.form_submit_button("Predict", type="primary")
    if go:
        payload = {k: (float(v) if k == "data_download_mb" else (int(v) if k in NUMERICAL else v)) for k, v in values.items()}
        result, err = None, None
        try:
            if mode == "FastAPI service":
                r = requests.post(f"{API_URL}/predict", json=payload, timeout=10)
                if r.ok:
                    result = r.json()
                else:
                    err = f"API returned {r.status_code}: {r.text}"
            else:
                from app.predictor import predict_record
                result = predict_record(payload)
        except requests.exceptions.RequestException:
            err = "Could not reach the API. Start it with `uvicorn app.main:app` or switch to 'Local model'."
        if err:
            st.error(err)
        elif result:
            p = result["threat_probability"]
            if result["prediction"] == 1:
                st.error(f"⚠️ {result['result']} — threat probability {p:.1%}")
            else:
                st.success(f"✅ {result['result']} — threat probability {p:.1%}")
            st.progress(min(max(p, 0.0), 1.0))
            if "anomaly_flag" in result:
                st.write("Isolation Forest anomaly flag: **%s** (unsupervised; an anomaly is unusual, not necessarily malicious)"
                         % ("anomalous" if result["anomaly_flag"] else "not anomalous"))
            st.info(result["explanation"])
    st.markdown("**Limitations:** the dataset's origin is unverified, results are very high on it probably because "
                "the classes are easy to separate, and a local demo is not a validated security system.")

with tab_metrics:
    mfile = REPORTS / "metrics.json"
    if not mfile.exists():
        st.warning("Run `python training/evaluate_model.py` first.")
    else:
        m = json.loads(mfile.read_text())
        st.subheader("Model comparison (held-out test set, n=%d)" % m["test_set_size"])
        st.dataframe(pd.read_csv(REPORTS / "model_comparison.csv"), hide_index=True)
        en = m["models"]["Elastic Net Logistic Regression"]
        c = st.columns(5)
        for col, k in zip(c, ["accuracy", "precision", "recall", "f1", "roc_auc"]):
            col.metric(k, f"{en[k]:.3f}")
        st.caption(m["caveat"])
        a, b = st.columns(2)
        a.image(str(REPORTS / "confusion_matrix.png")); b.image(str(REPORTS / "roc_curve.png"))
        st.image(str(REPORTS / "feature_importance.png"))

with tab_monitor:
    try:
        if mode == "FastAPI service":
            s = requests.get(f"{API_URL}/monitoring", timeout=10).json()
        else:
            from monitoring.monitor import monitoring_summary
            s = monitoring_summary()
        st.json(s)
    except Exception:
        st.warning("Monitoring summary unavailable (is the API running?).")
