"""Prediction logging + simple monitoring (data quality and input drift).

Inspect results from the project root:   python monitoring/monitor.py
Logs contain only timestamp, behavioural inputs, prediction and probability - NO user/event IDs.

Important: drift tells us the INPUTS look different from training data. It does NOT prove the model
got worse - that needs real ground-truth labels, which a live system rarely has immediately.
"""
import csv
import json
import sys
import threading
from datetime import datetime, timezone
from pathlib import Path

import pandas as pd
from scipy.stats import ks_2samp

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from training.common import CATEGORICAL, FEATURES, MODELS_DIR, NUMERICAL, RANGES  # noqa: E402

LOG_PATH = Path(__file__).resolve().parent / "prediction_logs.csv"
LOG_COLUMNS = ["timestamp_utc"] + FEATURES + ["prediction", "probability"]
MIN_ROWS_FOR_DRIFT = 30
_lock = threading.Lock()


def log_prediction(record: dict, prediction: int, probability: float, path: Path = LOG_PATH) -> None:
    row = {"timestamp_utc": datetime.now(timezone.utc).isoformat(timespec="seconds"),
           **{c: record.get(c) for c in FEATURES}, "prediction": int(prediction),
           "probability": round(float(probability), 6)}
    with _lock:
        new_file = not Path(path).exists()
        with open(path, "a", newline="") as f:
            w = csv.DictWriter(f, fieldnames=LOG_COLUMNS)
            if new_file:
                w.writeheader()
            w.writerow(row)


def load_logs(path: Path = LOG_PATH) -> pd.DataFrame:
    return pd.read_csv(path) if Path(path).exists() else pd.DataFrame(columns=LOG_COLUMNS)


def load_reference() -> dict:
    return json.loads((MODELS_DIR / "training_reference.json").read_text())


def monitoring_summary(path: Path = LOG_PATH, p_threshold: float = 0.05) -> dict:
    logs = load_logs(path)
    n = len(logs)
    summary = {"prediction_count": n, "note": "Drift != performance drop. Performance needs ground-truth labels."}
    if n == 0:
        summary["status"] = "No predictions logged yet."
        return summary
    ref = load_reference()
    summary.update({
        "first_prediction_utc": str(logs["timestamp_utc"].iloc[0]), "last_prediction_utc": str(logs["timestamp_utc"].iloc[-1]),
        "threat_predictions": int(logs["prediction"].sum()), "threat_rate": float(logs["prediction"].mean()),
        "mean_threat_probability": float(logs["probability"].mean()),
    })
    # data-quality: missing values, values outside the training min-max range, unseen categories
    quality = {"missing_values": int(logs[FEATURES].isna().sum().sum()),
               "outside_training_range": {c: int(((logs[c] < ref["numerical"][c]["min"]) | (logs[c] > ref["numerical"][c]["max"])).sum())
                                          for c in NUMERICAL},
               "unseen_categories": {c: int((~logs[c].isin(ref["categorical"][c].keys())).sum()) for c in CATEGORICAL}}
    quality["outside_training_range"] = {k: v for k, v in quality["outside_training_range"].items() if v}
    quality["unseen_categories"] = {k: v for k, v in quality["unseen_categories"].items() if v}
    summary["data_quality"] = quality
    # drift: two-sample Kolmogorov-Smirnov test of each numeric feature vs a saved training sample
    if n < MIN_ROWS_FOR_DRIFT:
        summary["drift"] = {"status": f"Need at least {MIN_ROWS_FOR_DRIFT} logged predictions (have {n})."}
        return summary
    rows = []
    for c in NUMERICAL:
        stat, p = ks_2samp(ref["numerical"][c]["values_sample"], logs[c].dropna())
        rows.append({"feature": c, "ks_statistic": round(float(stat), 4), "p_value": round(float(p), 4),
                     "drift_flag": bool(p < p_threshold)})
    drifted = [r["feature"] for r in rows if r["drift_flag"]]
    summary["drift"] = {"status": "drift suspected" if drifted else "no drift detected", "drifted_features": drifted,
                        "p_threshold": p_threshold, "details": rows}
    return summary


if __name__ == "__main__":
    print(json.dumps(monitoring_summary(), indent=2))
