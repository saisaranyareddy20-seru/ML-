"""API tests.   Run from the project root:   pytest -v
Needs the models to exist:  python training/train_model.py
"""
import sys
import tempfile
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from fastapi.testclient import TestClient  # noqa: E402

import monitoring.monitor as monitor  # noqa: E402
from app.main import app  # noqa: E402
from training.common import FEATURES  # noqa: E402
from training.train_model import get_split  # noqa: E402


@pytest.fixture(autouse=True)
def isolated_log(monkeypatch):
    """Keep test predictions out of the real prediction log."""
    monkeypatch.setattr(monitor, "LOG_PATH", Path(tempfile.mkdtemp()) / "test_logs.csv")
    import app.main as main
    original = main.log_prediction
    main.log_prediction = lambda *a, **k: original(*a, path=monitor.LOG_PATH, **k)
    yield
    main.log_prediction = original


@pytest.fixture(scope="module")
def client():
    with TestClient(app) as c:
        yield c


def record(label):
    _, X_test, _, y_test = get_split()
    r = X_test[y_test == label].iloc[0][FEATURES].to_dict()
    return {k: (v.item() if hasattr(v, "item") else v) for k, v in r.items()}


def test_root(client):
    assert client.get("/").status_code == 200


def test_health(client):
    r = client.get("/health")
    assert r.status_code == 200 and r.json()["model_loaded"] is True


def test_predict_normal_record_shape(client):
    r = client.post("/predict", json=record(0))
    assert r.status_code == 200
    body = r.json()
    assert body["result"] in ("Normal Activity", "Potential Insider Threat")
    assert 0.0 <= body["threat_probability"] <= 1.0
    assert "not proof" in body["explanation"]


def test_predict_threat_record_shape(client):
    r = client.post("/predict", json=record(1))
    assert r.status_code == 200 and r.json()["prediction"] in (0, 1)


def test_missing_field_rejected(client):
    bad = record(0); bad.pop("login_count")
    r = client.post("/predict", json=bad)
    assert r.status_code == 422 and r.json()["errors"]


def test_wrong_type_rejected(client):
    bad = record(0); bad["login_count"] = "many"
    assert client.post("/predict", json=bad).status_code == 422


def test_out_of_range_rejected(client):
    bad = record(0); bad["login_hour"] = 99
    assert client.post("/predict", json=bad).status_code == 422


def test_unknown_category_rejected(client):
    bad = record(0); bad["department"] = "Piracy"
    assert client.post("/predict", json=bad).status_code == 422


def test_unexpected_field_rejected(client):
    bad = record(0); bad["user_id"] = "USR1"
    assert client.post("/predict", json=bad).status_code == 422
