"""Tests of the saved model + monitoring that do NOT need FastAPI.
Run with `pytest -v`, or without pytest:  python tests/test_predictor_monitor.py
"""
import sys
import tempfile
from pathlib import Path

import joblib
import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from app.predictor import predict_record  # noqa: E402
from monitoring import monitor  # noqa: E402
from training.common import FEATURES, MODELS_DIR  # noqa: E402
from training.train_model import get_split  # noqa: E402


def rec(label, i=0):
    _, X, _, y = get_split()
    return {k: (v.item() if hasattr(v, "item") else v) for k, v in X[y == label].iloc[i][FEATURES].to_dict().items()}


def test_models_exist_and_reload():
    for f in ["elastic_net_pipeline", "random_forest_pipeline", "isolation_forest"]:
        assert joblib.load(MODELS_DIR / f"{f}.joblib") is not None
    assert (MODELS_DIR / "model_metadata.json").exists()


def test_prediction_output_contract():
    out = predict_record(rec(0))
    assert set(["prediction", "result", "threat_probability", "explanation"]) <= set(out)
    assert 0 <= out["threat_probability"] <= 1


def test_reloaded_pipeline_reproduces_reported_metrics():
    import json
    from sklearn.metrics import accuracy_score, recall_score
    _, X, _, y = get_split()  # (X_train, X_test, y_train, y_test) -> X, y = test
    m = joblib.load(MODELS_DIR / "elastic_net_pipeline.joblib")
    reported = json.loads((Path(MODELS_DIR).parent / "reports" / "metrics.json").read_text())["models"]["Elastic Net Logistic Regression"]
    pred = m.predict(X[FEATURES])
    assert abs(accuracy_score(y, pred) - reported["accuracy"]) < 1e-9  # X, y are the test split
    assert abs(recall_score(y, pred) - reported["recall"]) < 1e-9


def test_unseen_category_does_not_crash():
    r = rec(0); r["department"] = "NeverSeen"
    assert "prediction" in predict_record(r)


def test_logging_and_drift():
    path = Path(tempfile.mkdtemp()) / "logs.csv"
    assert monitor.monitoring_summary(path)["prediction_count"] == 0
    _, X, _, y = get_split()
    for i in range(40):
        r = {k: (v.item() if hasattr(v, "item") else v) for k, v in X.iloc[i][FEATURES].to_dict().items()}
        out = predict_record(r)
        monitor.log_prediction(r, out["prediction"], out["threat_probability"], path=path)
    s = monitor.monitoring_summary(path)
    assert s["prediction_count"] == 40 and "details" in s["drift"]
    assert "user_id" not in pd.read_csv(path).columns


if __name__ == "__main__":
    for name, fn in list(globals().items()):
        if name.startswith("test_"):
            fn(); print("PASS", name)
