# Insider Threat Detection Using Elastic Net Regularized Logistic Regression
Machine Learning (25SC2107E) · Team: G. Eesha Yuktha (2520030436), Sai Saranya (2520030258)

An end-to-end ML project: dataset → preprocessing → model training → evaluation → packaged model → FastAPI service → Streamlit dashboard → monitoring.

> **Honest data note.** The dataset's origin is unknown and it looks synthetic. Every model scores ~100 % on it, which says the two classes are easy to separate here, **not** that the system would work on real company logs. This is a learning project, not a validated security product.

## 1. Folder structure
```
data/        insider_threat_dataset_1500_rows.csv
notebooks/   Insider_Threat_EDA.ipynb          (original EDA, unchanged)
training/    common.py  train_model.py  evaluate_model.py
models/      elastic_net_pipeline.joblib  random_forest_pipeline.joblib  isolation_forest.joblib
             model_metadata.json  training_reference.json (drift reference)
app/         predictor.py (prediction logic)  main.py (FastAPI)  streamlit_app.py (UI)
monitoring/  monitor.py   prediction_logs.csv (created when predictions are made)
reports/     metrics.json  classification_report.txt  model_comparison.csv  leakage_check.csv
             confusion_matrix.png  roc_curve.png  feature_importance.png  (+ coefficient/importance CSVs)
tests/       test_api.py  test_predictor_monitor.py
```

## 2. Run it locally (exact commands)
```bash
python -m venv .venv
source .venv/bin/activate            # Windows: .venv\Scripts\activate
pip install -r requirements.txt

python training/train_model.py       # trains + saves models (about a minute)
python training/evaluate_model.py    # test-set metrics, plots, reports
pytest -v                            # automated tests

uvicorn app.main:app --reload        # API at http://127.0.0.1:8000  (Swagger docs: /docs)
# in a second terminal (venv active):
streamlit run app/streamlit_app.py   # dashboard at http://localhost:8501
python monitoring/monitor.py         # print the monitoring summary
```
Try the API: `curl http://127.0.0.1:8000/health`, then open `/docs` → `POST /predict` → "Try it out".
Example body (row 2 of the dataset):
```json
{"login_count":15,"login_hour":21,"failed_logins":2,"file_access_count":88,"sensitive_files_accessed":22,
 "after_hours_access":0,"external_device_usage":1,"data_download_mb":277.2,"access_frequency":28,
 "unique_files_accessed":51,"unusual_location":0,"unusual_login":1,"email_activity":28,"http_activity":99,
 "department":"IT","role":"Manager","device_type":"Workstation","operating_system":"Windows"}
```
(`event_id`, `user_id`, `event_date` and `unusual_activity_score` are deliberately **not** accepted.)

## 3. Design decisions
| Topic | Decision |
|---|---|
| Identifiers | `event_id`, `user_id`, `event_date` dropped – they would let a model memorise instead of learn behaviour. |
| `unusual_activity_score` | Excluded. It correlates 0.89 with the label and **97 %** of its variance can be predicted from the other numeric features, so it looks like a derived score and its construction is unknown. In CV on training data the model scores the same with or without it (`reports/leakage_check.csv`), so nothing is lost by excluding it. |
| Preprocessing | `ColumnTransformer`: median imputation + `StandardScaler` for numbers; most-frequent imputation + `OneHotEncoder(handle_unknown="ignore")` for categories. Inside a `Pipeline`, fitted on training folds only. |
| Split / CV | Stratified 80/20 split, `random_state=42`. 5-fold stratified CV on the training set only. |
| Tuning | `GridSearchCV` over `C` ∈ {0.01,0.1,1,10} × `l1_ratio` ∈ {0.1,0.3,0.5,0.7,0.9}. F1/recall/ROC-AUC are recorded; because many settings tie at F1 = 1.0, the winner is chosen by CV log-loss. Best: `C=10, l1_ratio=0.9` (at the edge of the grid – on perfectly separable data weaker regularisation always scores better). |
| Class imbalance | 20 % threats (300/1500) → `class_weight="balanced"`; threshold fixed at 0.5 (never tuned on test data). |
| Outliers | Kept – unusual records are exactly what we want to detect. |

## 4. Actual results (held-out test set, 300 rows, 60 threats)
| Model | Accuracy | Precision | Recall | F1 | ROC-AUC |
|---|---|---|---|---|---|
| **Elastic Net Logistic Regression (main)** | 1.00 | 1.00 | 1.00 | 1.00 | 1.000 |
| Random Forest (comparison) | 1.00 | 1.00 | 1.00 | 1.00 | 1.000 |
| Isolation Forest (unsupervised, label-free) | 0.92 | 1.00 | 0.60 | 0.75 | 0.997 (anomaly score) |

* 5-fold CV F1 on training data was also 1.0 for both supervised models.
* Elastic Net's L1 part set 23 of 33 encoded coefficients to exactly 0 (feature selection). Strongest positive features: `file_access_count`, `unique_files_accessed`, `sensitive_files_accessed`, `http_activity`, `access_frequency`.
* Random Forest ranks `unique_files_accessed`, `http_activity`, `file_access_count` highest – the two models broadly agree.
* Elastic Net and Random Forest tie on this dataset, so Elastic Net stays the main model because it is simple, fast, and its coefficients are explainable.
* Probabilities are often very close to 0 or 1 (separable data + weak regularisation) – treat them as scores, not calibrated risk.
* Isolation Forest never saw labels; with an assumed 10 % contamination it flagged 36 of 300 test rows, all genuine threats, but missed 24 of 60. **Anomaly ≠ confirmed threat.**

## 5. How one prediction travels (CO1)
1. User fills the Streamlit form (or sends JSON to `POST /predict`).
2. Streamlit sends the JSON to the FastAPI server (`API_URL`).
3. Pydantic validates types, ranges, allowed categories, missing/extra fields (422 with a readable message if invalid).
4. `predictor.py` builds a one-row DataFrame in the training column order.
5. The saved pipeline imputes, scales and one-hot encodes with the statistics learnt on the training set, then Elastic Net outputs a probability.
6. Probability ≥ 0.5 → "Potential Insider Threat", else "Normal Activity"; the response includes a "not proof of intent" explanation.
7. The request (inputs, prediction, probability, UTC time – no user IDs) is appended to `monitoring/prediction_logs.csv`.
8. Streamlit shows the result; `GET /monitoring` summarises counts, data quality and drift.

## 6. Monitoring
`monitoring/monitor.py` reports prediction count, threat rate, mean probability, missing values, values outside the training range, unseen categories, and per-feature **Kolmogorov–Smirnov drift** against a saved training sample (needs ≥ 30 logged predictions). Drift only says inputs changed. **Model performance degradation cannot be confirmed without true labels.**

## 7. CO mapping
| CO | Topic implemented | Where |
|---|---|---|
| CO1 | Full lifecycle, one-prediction walkthrough, prediction logging + data-quality/drift info | whole repo; §5; `monitoring/monitor.py` |
| CO2 | Elastic Net `LogisticRegression(penalty="elasticnet", solver="saga")`; `ColumnTransformer`+`Pipeline`; scaling; train-only fitting; L1/L2 and bias–variance | `training/train_model.py`; `reports/elastic_net_coefficients.csv` |
| CO3 | Random Forest comparison on the same test set; feature importance | `train_model.py`; `reports/random_forest_importance.csv`, `feature_importance.png` |
| CO4 | Isolation Forest fitted without labels; compared to labels only in evaluation | `train_model.py`; `metrics.json` → `isolation_forest_detail` |
| CO5 | Stratified split, CV on train only, `GridSearchCV`, accuracy/precision/recall/F1/ROC-AUC, confusion matrix, classification report, ROC, comparison table, imbalance discussion | `evaluate_model.py`; `reports/` |
| CO6 | Joblib packaging, FastAPI (`/`, `/health`, `/predict`, `/monitoring`, `/docs`), Streamlit UI, validation, error handling, logging, drift check, tests, deployment guide | `models/`, `app/`, `monitoring/`, `tests/`, §8 |

## 8. Online deployment (not yet done – needs your accounts)
Push the repo to GitHub **including `models/` and `reports/`** (small files); `prediction_logs.csv` is git-ignored.

**API on Render** (New → Web Service → your repo)
* Build: `pip install -r requirements.txt`
* Start: `uvicorn app.main:app --host 0.0.0.0 --port $PORT`
* Python version env var: `PYTHON_VERSION=3.12.3` (any 3.10+)
* After deploy: open `https://<your-service>.onrender.com/health`. Free instances sleep and lose log files on restart.

**Dashboard on Streamlit Community Cloud** (share.streamlit.io → New app)
* Main file: `app/streamlit_app.py`
* Secrets/env: `API_URL = "https://<your-service>.onrender.com"`
* If you skip the API, choose "Local model" in the sidebar – it loads the saved pipeline directly.

The saved `.joblib` files only load with a compatible scikit-learn version; if versions differ, rerun `python training/train_model.py` on the host or pin the version used here (see `model_metadata.json`).

## 9. Simple workflow explanation
1. **Collect/inspect data** – 1,500 activity records, 20 % labelled as threats (EDA notebook).
2. **Clean & select** – drop IDs/dates and the suspicious score; check missing values/duplicates (none).
3. **Preprocess** – scale numbers so no feature dominates, one-hot encode text categories.
4. **Train** – Elastic Net learns a weight per feature; Random Forest is the benchmark; Isolation Forest finds oddities without labels.
5. **Tune & validate** – cross-validation on training data picks hyperparameters.
6. **Test once** on data never touched before.
7. **Package** pipeline with Joblib.
8. **Serve** with FastAPI; **use** via Streamlit; **watch** with monitoring.

## 10. Review presentation outline (≈ 8 slides)
1. Problem: insider threats (authorised users misusing access); why ML helps; recall matters (a missed threat costs more than a false alarm).
2. Dataset: 1,500 rows, 23 columns, 20 % threats, no missing values/duplicates, unknown (likely synthetic) origin.
3. EDA highlights from the notebook: class imbalance, features higher for threats, correlated features → motivates Elastic Net.
4. Preprocessing & leakage: dropped IDs/dates; `unusual_activity_score` excluded (derived, r=0.89 with label).
5. Algorithms: Elastic Net LR (main), Random Forest (comparison), Isolation Forest (anomaly).
6. Evaluation: split/CV/GridSearchCV, metrics table, confusion matrix, ROC, feature importance; why 100 % is suspicious.
7. Deployment: architecture diagram (Streamlit → FastAPI → pipeline → log/monitor), live demo.
8. Limitations & future work: synthetic data, no real labels, drift ≠ performance, try harder/real datasets (e.g. CERT), calibration, threshold tuning for recall.

## 11. Likely viva questions
* **What is an insider threat?** A person with legitimate access (employee, contractor) who misuses it – stealing data, sabotage, or leaking secrets.
* **Why Logistic Regression for classification?** It outputs a probability between 0 and 1 via the sigmoid, is fast, and its coefficients are easy to explain.
* **What is Elastic Net?** Logistic loss + a penalty mixing L1 (sum of |weights|) and L2 (sum of squared weights). `C` is inverse strength; `l1_ratio` is the L1 share.
* **Why combine L1 and L2?** L1 zeroes useless features (selection); L2 shrinks correlated features together and stabilises them. Our features are correlated, so the mix helps.
* **Why feature scaling?** The penalty treats all weights equally, so features must share a scale (e.g. `data_download_mb` is in hundreds, flags are 0/1). Also helps the solver converge.
* **Why train/test split and cross-validation?** The test set gives an honest final estimate on unseen data; CV on the training set tunes hyperparameters without touching the test set.
* **Precision, recall, F1, ROC-AUC?** Precision = TP/(TP+FP); recall = TP/(TP+FN); F1 = their harmonic mean; ROC-AUC = chance a random threat scores higher than a random normal record, across all thresholds.
* **Why Random Forest?** A non-linear tree-ensemble benchmark; it shows whether a more complex model beats the linear one (here they tie).
* **What is anomaly detection?** Finding records that differ from the bulk of the data, without labels. Isolation Forest isolates odd points with fewer random splits.
* **How does the API talk to the frontend?** Streamlit sends an HTTP POST with JSON to `/predict`; FastAPI replies with JSON.
* **How is the model saved/loaded?** `joblib.dump(pipeline, file)` after training; `joblib.load` once when the API starts. The pipeline includes preprocessing, so training and serving transform data identically.
* **How is drift monitored?** Compare the distribution of each logged input feature with a saved training sample using a KS test; flag small p-values. It doesn't prove accuracy dropped.
* **What happens on a new request?** See §5.
* **Why is accuracy 100 %? (expect this!)** The data is likely synthetic and easily separable; we checked leakage, excluded the suspicious score and IDs, and still got the same CV result, so we do not claim real-world performance.
* **Why exclude `unusual_activity_score`?** Unknown construction, 0.89 correlation with the label, 97 % predictable from other features – a derived score that adds nothing and risks leakage.
